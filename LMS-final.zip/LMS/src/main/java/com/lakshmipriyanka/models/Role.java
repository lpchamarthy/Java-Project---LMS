package com.lakshmipriyanka.models;

public enum Role {
	USER, ADMIN;
}
