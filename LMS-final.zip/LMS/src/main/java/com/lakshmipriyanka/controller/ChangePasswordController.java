package com.lakshmipriyanka.controller;

import com.lakshmipriyanka.controller.helpers.StageHelper;
import com.lakshmipriyanka.dao.UserDAO;
import com.lakshmipriyanka.exceptions.InvalidUserException;
import com.lakshmipriyanka.exceptions.UnAuthorizedException;
import com.lakshmipriyanka.models.User;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.text.Text;

public class ChangePasswordController extends BaseController {

	@FXML
	private PasswordField oldPass;
	@FXML
	private PasswordField newPass;
	@FXML
	private PasswordField confirmPass;
	@FXML
	private Text errorMessage;

	public ChangePasswordController() {
	}

	@Override
	public void initController() {
		setTitle("Change Password for " + context.getUser().getName());
	}

	public void changePassword() {
		UserDAO userDao = new UserDAO();
		User user = this.context.getUser();
		String oldPassword = oldPass.getText();
		String newPassword = newPass.getText();
		String confirmPassword = confirmPass.getText();
		// If new password & confirm password does not match
		if (!newPassword.equals(confirmPassword)) {
			errorMessage.setText("New password & Confirm password does not match");
			newPass.clear();
			confirmPass.clear();
		} else {
			try {
				if (userDao.isValidUser(UserDAO.requestForLoginValidation(user.getUserName(), oldPassword))) {
					userDao.updatePassword(UserDAO.requestForNewPassword(user, oldPassword, newPassword));
					back();
				}
			} catch (InvalidUserException | UnAuthorizedException e) {
				errorMessage.setText("Old password does not match records");
			}
		}

	}

	public void back() {
		StageHelper.setScene(context, "UserHomeView");
	}

}
