-- read_user_by_username.sql
SELECT * from clp_myuser where username = ?;