-- read_last_borrow_id.sql
SELECT MAX(borrowid) AS newKey FROM clp_borrow