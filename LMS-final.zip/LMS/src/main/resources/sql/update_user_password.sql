-- update_user_password.sql
UPDATE clp_myuser SET password = ? WHERE username = ? AND password = ?;