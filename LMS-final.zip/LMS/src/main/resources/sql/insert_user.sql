-- insert_user.sql
INSERT INTO clp_myuser ( name, department, role, username, password ) values ( ?, ?, ?, ?, ? );