-- insert_user.sql
UPDATE clp_myuser SET name = ?, department = ?, role = ?, userName = ? WHERE uid = ?;