-- create_new_borrow.sql 
-- <Status, UID, BID>
INSERT INTO clp_borrow values (default, ?, ?, ?)