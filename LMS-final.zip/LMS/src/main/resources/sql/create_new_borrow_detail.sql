-- create_new_borrow_detail.sql
INSERT INTO clp_borrowdetails (borrowid, BorrowDate) values(?, now());