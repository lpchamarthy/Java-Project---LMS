-- delete_book.sql
DELETE FROM clp_book WHERE bid = ?;