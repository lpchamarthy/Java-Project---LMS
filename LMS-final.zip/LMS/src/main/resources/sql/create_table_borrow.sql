-- create_table_borrow.sql
CREATE TABLE IF NOT EXISTS clp_Borrow (	BorrowID int not null auto_increment,
										Status varchar(20),
										UID int,
										BID int,
										Primary Key (BorrowID),
										FOREIGN KEY(UID) REFERENCES clp_MyUser(UID),
										FOREIGN KEY(BID) REFERENCES clp_Book(BID) );
