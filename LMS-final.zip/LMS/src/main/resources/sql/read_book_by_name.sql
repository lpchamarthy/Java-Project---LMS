-- read_book_by_name.sql
SELECT * from clp_book where name = ?;