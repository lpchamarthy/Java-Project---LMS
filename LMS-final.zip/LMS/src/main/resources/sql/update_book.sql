-- insert_user.sql
UPDATE clp_book SET name=?, author=?, category=?, cost=?, rentalcost=?, quantity=? WHERE bid = ?;