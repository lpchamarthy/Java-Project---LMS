-- insert_user.sql
INSERT INTO clp_book ( name, author, category, cost, rentalcost, quantity ) values ( ?, ?, ?, ?, ?, ? );