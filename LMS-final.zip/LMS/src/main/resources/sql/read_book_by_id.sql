-- read_book_by_id.sql
SELECT * from clp_book where bid = ?;