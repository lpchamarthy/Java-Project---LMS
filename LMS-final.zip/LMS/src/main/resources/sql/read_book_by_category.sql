-- read_book_by_category.sql
SELECT * from clp_book where category = ?;