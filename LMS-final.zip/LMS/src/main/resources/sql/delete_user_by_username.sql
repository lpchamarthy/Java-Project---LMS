-- delete_user_by_username.sql
DELETE FROM clp_myUser WHERE userName = ?;