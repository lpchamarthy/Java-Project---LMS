-- read_book_by_author.sql
SELECT * from clp_book where author = ?;